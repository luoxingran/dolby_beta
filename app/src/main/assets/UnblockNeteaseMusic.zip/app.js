#!/usr/bin/env node

require('./src/bootstrap')('app');
